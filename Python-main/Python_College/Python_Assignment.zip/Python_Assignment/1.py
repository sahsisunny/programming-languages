h = float(input("Enter the Height of Triangle:- "))
b = float(input("Enter the Base of Tringel:- "))
area = h * b / 2
print("Area of Triangle is:- ", area)
