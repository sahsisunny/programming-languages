s1 = {1, 2, 3, 5}  # first set
s2 = {4, 5, 6}  # second set
p = [[ss1, ss2] for ss1 in s1 for ss2 in s2]
print(p)
