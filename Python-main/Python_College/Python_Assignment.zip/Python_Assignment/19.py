String = "{'A':13, 'B':14, 'C':15 }"
Dict = eval(String)
print(Dict)
print(Dict['A'])
print(Dict['C'])
