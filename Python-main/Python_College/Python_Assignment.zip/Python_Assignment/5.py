a = int(input("Enter Start Number: "))
b = int(input("Enter End Number: "))
c = int(input("Enter Step Number: "))
for i in range(a, b, c):
    print(i, end=" ,    ")
