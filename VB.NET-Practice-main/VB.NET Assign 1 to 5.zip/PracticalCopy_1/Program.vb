Module Program
    Sub Main(args As String())
        Dim msg As String
        Console.Write("Enter the message: ")
        msg = Console.ReadLine()
        Console.WriteLine("Your Message is : {0}", msg)
    End Sub
End Module
